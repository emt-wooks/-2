현장 음성메모 Android 앱 프로젝트
=================================

기능
- 말하기 시작 → 한국어 음성 받아쓰기
- 인식이 한 번 끝나도 자동으로 다시 듣기 시작
- 받아쓴 텍스트를 직접 수정 가능
- 시간/혈압/맥박/산소포화도 등 간단한 표현 정리
- 정리된 문장 복사
- 인터넷 주소에 접속하는 웹앱이 아니라 Android 네이티브 앱

실행 방법
1. PC에 Android Studio 설치
2. 이 폴더(FieldVoiceMemoAndroid)를 Android Studio에서 Open
3. Gradle Sync 진행
4. Android 휴대폰을 USB로 연결하고 개발자 옵션/USB 디버깅 허용
5. Run 버튼을 눌러 앱 설치
6. 첫 실행 시 마이크 권한 허용

APK 만들기
Android Studio 메뉴:
Build → Build App Bundle(s) / APK(s) → Build APK(s)

주의
- 이 프로젝트에는 컴파일된 APK가 포함되어 있지 않습니다.
- 현재 실행 환경에는 Android SDK/Gradle 빌드 환경이 없어 APK 자체를 여기서 컴파일하지 못했습니다.
- Android의 SpeechRecognizer는 기기/Google 음성 서비스 설정에 따라 동작 방식이 달라질 수 있습니다.
- 공식 구조·구급 기록으로 사용할 경우 최종 내용을 반드시 사람이 확인해야 합니다.
