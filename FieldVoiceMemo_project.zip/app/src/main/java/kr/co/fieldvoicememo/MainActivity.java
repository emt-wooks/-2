package kr.co.fieldvoicememo;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int AUDIO_PERMISSION_CODE = 1001;

    private EditText rawText;
    private TextView statusText;
    private TextView outputText;
    private Button startButton;
    private Button stopButton;

    private SpeechRecognizer speechRecognizer;
    private Intent recognizerIntent;
    private boolean keepListening = false;
    private boolean isListening = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rawText = findViewById(R.id.rawText);
        statusText = findViewById(R.id.statusText);
        outputText = findViewById(R.id.outputText);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);

        Button tidyButton = findViewById(R.id.tidyButton);
        Button copyButton = findViewById(R.id.copyButton);
        Button clearButton = findViewById(R.id.clearButton);

        setupSpeechRecognizer();

        startButton.setOnClickListener(v -> startVoiceMemo());
        stopButton.setOnClickListener(v -> stopVoiceMemo());

        tidyButton.setOnClickListener(v ->
                outputText.setText(tidyText(rawText.getText().toString())));

        copyButton.setOnClickListener(v -> {
            ClipboardManager cm =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(
                    "현장 음성메모", outputText.getText().toString()));
            Toast.makeText(this, "정리된 문장을 복사했습니다.", Toast.LENGTH_SHORT).show();
        });

        clearButton.setOnClickListener(v -> {
            stopVoiceMemo();
            rawText.setText("");
            outputText.setText("정리된 문장이 여기에 표시됩니다.");
            statusText.setText("초기화했습니다.");
        });
    }

    private void setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("이 기기에서는 음성인식을 사용할 수 없습니다.");
            startButton.setEnabled(false);
            return;
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);

        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                isListening = true;
                statusText.setText("🎙 듣고 있습니다. 계속 말씀하세요.");
            }

            @Override
            public void onBeginningOfSpeech() {
                statusText.setText("음성 인식 중...");
            }

            @Override
            public void onRmsChanged(float rmsdB) { }

            @Override
            public void onBufferReceived(byte[] buffer) { }

            @Override
            public void onEndOfSpeech() {
                statusText.setText("문장을 처리하고 있습니다...");
            }

            @Override
            public void onError(int error) {
                isListening = false;

                if (!keepListening) {
                    statusText.setText("음성 기록이 중지되었습니다.");
                    return;
                }

                // NO_MATCH / SPEECH_TIMEOUT 등은 현장에서 자연스럽게 발생하므로 재시작
                statusText.setText("다시 듣는 중...");
                restartListeningSoon();
            }

            @Override
            public void onResults(Bundle results) {
                isListening = false;
                ArrayList<String> matches =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

                if (matches != null && !matches.isEmpty()) {
                    appendRecognizedText(matches.get(0));
                }

                if (keepListening) {
                    restartListeningSoon();
                } else {
                    statusText.setText("음성 기록이 중지되었습니다.");
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                ArrayList<String> partial =
                        partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (partial != null && !partial.isEmpty()) {
                    statusText.setText("인식 중: " + partial.get(0));
                }
            }

            @Override
            public void onEvent(int eventType, Bundle params) { }
        });
    }

    private void startVoiceMemo() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    AUDIO_PERMISSION_CODE);
            return;
        }

        keepListening = true;
        startListeningNow();
    }

    private void startListeningNow() {
        if (speechRecognizer == null || isListening) return;

        try {
            speechRecognizer.startListening(recognizerIntent);
            statusText.setText("마이크 준비 중...");
        } catch (Exception e) {
            statusText.setText("음성인식을 시작하지 못했습니다.");
        }
    }

    private void restartListeningSoon() {
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(() -> {
            if (keepListening) startListeningNow();
        }, 450);
    }

    private void stopVoiceMemo() {
        keepListening = false;
        handler.removeCallbacksAndMessages(null);

        if (speechRecognizer != null) {
            try {
                speechRecognizer.stopListening();
            } catch (Exception ignored) { }
        }
        isListening = false;
        statusText.setText("음성 기록이 중지되었습니다.");
    }

    private void appendRecognizedText(String text) {
        String current = rawText.getText().toString().trim();
        if (!current.isEmpty()) current += " ";
        rawText.setText(current + text.trim());
        rawText.setSelection(rawText.getText().length());
        statusText.setText("기록됨. 계속 듣는 중...");
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == AUDIO_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startVoiceMemo();
            } else {
                statusText.setText("마이크 권한이 필요합니다.");
            }
        }
    }

    private String tidyText(String input) {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty()) return "입력된 내용이 없습니다.";

        s = s.replaceAll("\\s+", " ");

        Pattern time = Pattern.compile("(\\d{1,2})시\\s*(\\d{1,2})분");
        Matcher tm = time.matcher(s);
        StringBuffer tsb = new StringBuffer();
        while (tm.find()) {
            String hh = String.format(Locale.KOREA, "%02d", Integer.parseInt(tm.group(1)));
            String mm = String.format(Locale.KOREA, "%02d", Integer.parseInt(tm.group(2)));
            tm.appendReplacement(tsb, hh + ":" + mm);
        }
        tm.appendTail(tsb);
        s = tsb.toString();

        s = s.replaceAll(
                "혈압\\s*(\\d{2,3})\\s*(?:에|/)\\s*(\\d{2,3})",
                "혈압 $1/$2 mmHg");
        s = s.replaceAll(
                "맥박\\s*(\\d{2,3})(?!\\s*회)",
                "맥박 $1회/분");
        s = s.replaceAll(
                "산소포화도\\s*(\\d{2,3})\\s*%?",
                "산소포화도 $1%");

        s = s.replace("오른쪽", "우측");
        s = s.replace("왼쪽", "좌측");

        String[] phrases = {
                "환자 접촉", "현장 도착", "의식 명료", "의식 없음",
                "통증 있음", "부종 있음", "출혈 있음", "출혈 없음",
                "부목 적용", "산소 적용", "들것으로 하산",
                "구급대 인계", "병원 이송", "활동 종료"
        };

        for (String phrase : phrases) {
            s = s.replaceAll(
                    Pattern.quote(phrase) + "(?![.,])",
                    Matcher.quoteReplacement(phrase + "."));
        }

        s = s.replaceAll("\\.\\s*", ". ");
        s = s.replaceAll("([%]|mmHg|회/분)\\s+(?=[가-힣])", "$1. ");
        s = s.replaceAll("\\s+\\.", ".");
        s = s.replaceAll("\\.{2,}", ".");
        s = s.trim();

        if (!(s.endsWith(".") || s.endsWith("!") || s.endsWith("?"))) {
            s += ".";
        }

        return s;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        keepListening = false;
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }
}
